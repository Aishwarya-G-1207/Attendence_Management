import tkinter as tk
from tkinter import ttk

def admin_panel():
    win = tk.Tk()
    win.title("Admin Panel")
    win.geometry('900x600')
    win.configure(bg="lightgrey")

    # Sidebar
    sidebar = tk.Frame(win, width=200, bg="darkgrey", height=600, relief="raised", borderwidth=2)
    sidebar.pack(side="left", fill="y")

    # Content Frames
    content_frame = tk.Frame(win, bg="white", width=700, height=600)
    content_frame.pack(side="right", fill="both", expand=True)

    student_details_frame = tk.Frame(win, bg="white", width=700, height=600)

    def show_dashboard():
        student_details_frame.pack_forget()
        content_frame.pack(fill="both", expand=True)

    def show_student_details():
        content_frame.pack_forget()
        student_details_frame.pack(fill="both", expand=True)

    # Sidebar Buttons
    dashboard_btn = ttk.Button(sidebar, text="Dashboard", command=show_dashboard)
    dashboard_btn.pack(pady=20, padx=20, fill="x")

    student_btn = ttk.Button(sidebar, text="Student Details", command=show_student_details)
    student_btn.pack(pady=20, padx=20, fill="x")

    logout_btn = ttk.Button(sidebar, text="Logout", command=win.destroy)
    logout_btn.pack(side="bottom", pady=20, padx=20, fill="x")

    # Dashboard Content
    dashboard_label = ttk.Label(content_frame, text="Welcome to the Admin Dashboard",
                                font=("Helvetica", 18, "bold"), background="white")
    dashboard_label.pack(pady=50)

    stats_frame = tk.Frame(content_frame, bg="white")
    stats_frame.pack(pady=20)

    ttk.Label(stats_frame, text="Total Students: 3", font=("Helvetica", 14), background="white").pack(side="left", padx=20)
    ttk.Label(stats_frame, text="Attendance Avg: 85%", font=("Helvetica", 14), background="white").pack(side="left", padx=20)

    # Student Details Content
    tree = ttk.Treeview(student_details_frame, columns=("ID", "Name", "Attendance"), show="headings", height=15)
    tree.heading("ID", text="Student ID")
    tree.heading("Name", text="Name")
    tree.heading("Attendance", text="Attendance (%)")
    tree.column("ID", anchor="center", width=100)
    tree.column("Name", anchor="w", width=300)
    tree.column("Attendance", anchor="center", width=100)
    tree.pack(pady=20, padx=20, fill="both", expand=True)

    # Example Data
    students = [("101", "Alice", "90%"), ("102", "Bob", "85%"), ("103", "Charlie", "80%")]
    for student in students:
        tree.insert("", "end", values=student)

    # Styles
    style = ttk.Style()
    style.configure("Treeview.Heading", font=("Helvetica", 12, "bold"))
    style.configure("Treeview", font=("Helvetica", 10))
    
    win.mainloop()

# Run the admin panel
admin_panel()
